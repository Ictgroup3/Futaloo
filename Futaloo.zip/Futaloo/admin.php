<?php
    include_once 'header.php';
?>


<div class="sign-in">
    <h3 class="stand-alone">Manage Facilities</h3>
    <div class="update-box">
        <form action="includes/update.inc.php" method="POST">
            <select name="facility" id="facility">
                <option value="default">Choose convenience</option>
                <option value="etf">ETF</option>
                <option value="seet">SEET</option>
                <option value="saat">SAAT</option>
                <option value="set">SET</option>
                <option value="crc">CRC</option>
                <option value="smat">SMAT</option>
                <option value="sols">SOLS</option>
                <option value="soc">SOC</option>
                <option value="sops">SOPS</option>
                <option value="library">LIBRARY</option>
                <option value="3in1old">3-IN-1 OLD</option>
                <option value="3in1new">3-IN-1 NEW</option>
                <option value="acad">ACADEMIC BUILDING</option>
                <option value="ent">ENT. BUILDING</option>
                <option value="sub">SUB</option>
                <option value="boc">BLOCK OF CLASSROOMS</option>
                <option value="1kcap">1000 CAPACITY</option>
                <option value="sems">SEMS</option>
            </select>
            <select name="status" id="status">
                <option value="default">Set status</option>
                <option value="AVAILABLE">Available</option>
                <option value="NOT AVAILABLE">Not Available</option>
                <option value="NO WATER">No water</option>
                <option value="NOT CLEAN">Not Clean</option>
            </select>
            <button type="submit" name="apply" id="login">Apply</button>
    </div>
    </form>
</div>






<div class="side-content-box">
    <div class="review-box">
        <form action="review.inc.php" method="POST">

        </form>
    </div>
    <div class="report-box">
        <form action="report.inc.php">

        </form>

    </div>
</div>
</div>
<div class="interventions">

</div>
</div>



<?php
    include_once 'footer.php';
?>
