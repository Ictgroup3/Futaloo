</div>
<div class="footer">
    <ul class="group-name">
        <li>Molo</li>
        <li class="even">Ella</li>
        <li>Ivy</li>
        <li class="even">Pelma</li>
        <li>Moyin</li>
        <li class="even">Oak</li>
        <li>Mufasa</li>
        <li class="even">Favour</li>
        <li>Peace</li>
        <li class="even">Ehiz</li>
        <li>Feyi</li>
        <li class="even">Fowowe</li>
    </ul>
</div>

</body>
</html>
