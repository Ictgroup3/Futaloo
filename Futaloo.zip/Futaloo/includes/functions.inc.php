<?php

function emptyInputSignup($name, $email, $confirmEmail, $username, $pwd, $pwdConfirm) {
    if (empty($name) || empty($email) || empty($confirmEmail) || empty($username) || empty($pwd) || empty($pwdConfirm)) {
        $result = true;
    }
    else {
        $result = false;
    }
    return $result;
}

function invalidUid($username) {
    if(!preg_match("/^[a-zA-Z0-9]*$/", $username)) {
        $result = true;
    }
    else {
        $result = false;
    }
    return $result;
}


function invalidEmail($email) {
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $result = true;
    }
    else {
        $result = false;
    }
    return $result;
}

function pwdMatch($pwd, $pwdConfirm)
{
    if ($pwd !== $pwdConfirm) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}
    function emailMatch($email, $confirmEmail) {
        if ($email !== $confirmEmail) {
            $result = true;
        }
        else {
            $result = false;
        }
        return $result;
    }
    function usernameExists($conn, $username, $email) {
        $sql = "SELECT * FROM  USERS WHERE  USER_UID = ? OR USER_EMAIL = ?;";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../signup.php?error=stmtfailed");
            exit();
        }

        mysqli_stmt_bind_param($stmt, "ss",  $username, $email);
        mysqli_stmt_execute($stmt);

        $resultData = mysqli_stmt_get_result($stmt);

        if($row = mysqli_fetch_assoc($resultData)) {
            return $row;
        }
        else {
            $result = false;
            return $result;
        }
        mysqli_stmt_close($stmt);
    }

    function createUser($conn, $name, $email, $username, $pwd) {
        $sql = "INSERT INTO users(USER_NAME, USER_EMAIL, USER_UID, USER_PWD) VALUES (?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../signup.php?error=stmtfailed");
            exit();
        }

        $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

        mysqli_stmt_bind_param($stmt, "ssss",  $name, $email, $username, $hashedPwd );
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location:../signup.php?error=none");
    }

    function emptyInputLogin($username, $pwd) {
        if (empty($username) || empty($pwd)) {
            $result = true;
        }
        else {
            $result = false;
        }
        return $result;
    }

    function loginUser($conn, $username, $pwd) {
        $uidExists = usernameExists($conn, $username, $username);

        if($uidExists === false) {
            header("location: ../login.php?error=wronglogin");
            exit();
        }

            $pwdHashed = $uidExists["USER_PWD"];
            $checkPwd = password_verify($pwd, $pwdHashed);

            if($checkPwd === false) {
                header("location: ../login.php?error=wronglogin");
                exit();
            }
            else if ($checkPwd === true) {
                session_start();
                $_SESSION["userid"] = $uidExists["USER_ID"];
                $_SESSION["userUid"] = $uidExists["USER_UID"];
                header("location: ../index.php");
                exit();
            }
    }

    function updateFacility($conn, $facility, $status) {
        $sql = "UPDATE FACILITY SET STATUS = ? WHERE NAME = ?;";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../admin.php?updateFailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "ss", $status, $facility);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location: ../admin.php?updateSuccessful");
    }

    function emptyInputMessage($name, $gender, $location, $message) {
        if (empty($name) || empty($gender) || empty($location) || empty($message)) {
            $result = true;
        }
        else {
            $result = false;
        }
        return $result;
    }

    function loginMessage($conn, $name, $gender, $location, $message) {
        $sql = "INSERT INTO FEEDBACK(NAME, GENDER, LOCATION, MESSAGE) VALUES(?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../index.php?feedbacknotsent");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "ssss", $name, $gender, $location, $message);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location: ../index.php?feedbacksuccessful");
    }

    function fetchStatus($conn, $facility) {
        $sql = "SELECT STATUS FROM FACILITY WHERE NAME = ?;";
        $stmt = mysqli_stmt_init($conn);
        if(!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: index.php?error=somethingwentwrong");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "s", $facility);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $status = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);
        return $status;
    }