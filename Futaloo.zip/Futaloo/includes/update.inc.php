<?php
    if(isset($_POST["apply"])) {

        $facility = $_POST["facility"];
        $status = $_POST["status"];
        require_once 'dbh.inc.php';
        require_once 'functions.inc.php';

        updateFacility($conn, $facility, $status);
        session_start();
        $_SESSION["$facility"] = $status;

    }
    else {
        header("location: ../login.php");
        exit();
    }