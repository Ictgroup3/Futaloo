<?php

if (isset($_POST["submit"])) {
    $name = $_POST["name"];
    $gender = $_POST["gender"];
    $location = $_POST["location"];
    $message = $_POST["message"];

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';

    if(emptyInputMessage($name, $gender, $location, $message) !== false) {
        header("location: ../index.php?error=emptyinput");
        exit();
    }

    loginMessage($conn, $name, $gender, $location, $message);
}
else {
    header("location: ../index.php");
    exit();
}
