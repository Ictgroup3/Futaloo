<?php
    include_once 'header.php';
?>

<div class="sign-in">
    <form action="includes\login.inc.php" method="POST">
        <div class="login-param">
            <label for="userId">User I.D.</label>
            <input type="text" id="userId" name="userId" placeholder="Enter I.D. or Email" required  />
        </div>
        <div class="login-param">
            <label for="userPwd">Password</label>
            <input type="password" name="userPwd" id="userPwd">
        </div>
        <button type="submit" name="submit" id="login">Log In</button>
        <p>Don't have an account? &nbsp; &nbsp;<a href="signup.php">Sign Up</a></p>

        <?php
        if (isset($_GET["error"])) {
            if ($_GET["error"] == "emptyinput") {
                echo "<p>Fill in all fields!</p>";
            }
            else if ($_GET["error"] == "wronglogin") {
                echo "<p>Incorrect log in details!</p>";
            }
        }
        ?>
    </form>
</div>

<?php
    include_once 'footer.php';
?>
