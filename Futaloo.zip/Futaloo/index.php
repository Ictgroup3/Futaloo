<?php
    include_once 'header.php';
?>
<div class="first-section">
    <div class="homepage-info">
        Sharp sharp solutions to all dis' sanitation wahala
    </div>
    <div class="search-trigger">
        You dey find toilet?<br><br>
        <span class="check-button"><a href="facilities.php">Check here!</a></span>
    </div>
</div>
<div class="second-section">
    <div class="peptalk">
        <p class="heading">The Goal</p>
        <p>To reinforce human dignity through the provision of safely managed sanitation facilities</p>
    </div>
    <div class="peptalk" id="middle-peptalk">
        <p class="heading">The Strategy</p>
        <p>To achieve our goal by providing a platform for accessing an assessing these facilities</p>
    </div>
    <div class="peptalk">
        <p class="heading">Our Duty</p>
        <p>To join hands and actively participate in achieving our goal of dignifying sanitation for all</p>
    </div>
</div>
<div class="third-section">
    <div class="info">
        <div class="volunteer-option">
            <p class="volunteer-peptalk">
                Achieving safe and healthy sanitation for all is one of the
                <abbr title="United Nations Development Programme">UNDP</abbr>
                <abbr title="Sustainable Development Goals">SDGs</abbr>.
                To contribute our quota in attaining this goal, we seek to
                completely eliminate open defecation from our campus while
                constantly monitoring and improving our sanitation facilities
                until it conforms to the <abbr title="Joint Monitoring Programme">
                    JMP</abbr> standards.
            </p>
            You'd like to join the movement?<br><br>
            <span><a class="volunteer-button" href="signup.php">Volunteer here!</a></span>
        </div>
    </div>
    <div class="info">
        <div class="report-info">
            <h3 class="contact-info">Let's get in touch</h3>
            <p class="intro-text">Do you have complaints about the management of your toilets?</p>
            <p class="intro-text">Do you see a room for improvements?</p>
            <p class="intro-text">Kindly get us informed and get those issues sorted out.</p>
            <div class="contact-medium">
                <p>info@futaloo.com</p>
            </div>
            <div class="contact-medium">
                <p>Federal University of Technology Akure</p>
            </div>
            <div class="contact-medium">
                <p>+234 8099954321</p>
            </div>
        </div>
    </div>
    <div class="info">
        <div class="contact-form">
            <form action="includes/feedback.inc.php" autocomplete="off" method="POST">
                <h3 class="form-title">Drop your complaints</h3>
                <div class="input-container">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name" class="input" required>
                </div>
                <div class="input-container">
                    <label for="gender">Gender</label>
                    <input type="text" name="gender" id="gender" class="input" required>
                </div>
                <div class="input-container">
                    <label for="location">Location</label>
                    <input type="text" id="location" name="location" class="input" required>
                </div>
                <div class="input-container textarea">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" cols="30" rows="10" class="input" required></textarea>
                </div>
                <div class="send-button">
                    <button type="submit" name="submit" class="btn">Send</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php
    include_once 'footer.php'
?>