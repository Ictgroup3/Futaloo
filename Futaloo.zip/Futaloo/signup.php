<?php
    include_once 'header.php';
?>


<section>
    <div class="sign-in">
        <form action="includes\signup.inc.php" method="POST">
            <input type="text" name="fullName" id="fullName" placeholder="Full Name" required>
            <input type="email" name="email" id="email" placeholder="Email" required>
            <input type="email" name="confirmEmail" id="confirmEmail" placeholder="Confirm Email" required>
            <input type="text" name="username" id="username" placeholder="Username" required>
            <input type="password" name="password" id="password" placeholder="Password" required>
            <input type="password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" required>
            <button type="submit" name="submit" id="login">Sign Up</button>
            <p>Already have an account? &nbsp;&nbsp;<a href="login.php">Log In</a></p>
            <?php
            if (isset($_GET["error"])) {
                if ($_GET["error"] == "emptyinput") {
                    echo "<p>Fill in all fields!</p>";
                }
                else if ($_GET["error"] == "invaliduid") {
                    echo "<p>Choose a proper username!</p>";
                }
                else if ($_GET["error"] == "invalidemail") {
                    echo "<p>Choose a proper email!</p>";
                }
                else if ($_GET["error"] == "passwordsdontmatch") {
                    echo "<p>Passwords doesn't match!</p>";
                }
                else if ($_GET["error"] == "stmtfailed") {
                    echo "<p>Something went wrong!</p>";
                }
                else if ($_GET["error"] == "usernametaken") {
                    echo "<p>Username already taken!</p>";
                }
                else if ($_GET["error"] == "none") {
                    echo "<p>Sign up successful proceed to log in</p>";
                }
            }
            ?>
        </form>
    </div>

</section>

<?php
    include_once 'footer.php';
?>

