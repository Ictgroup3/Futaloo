<?php
    include_once 'header.php';
    require_once 'includes/functions.inc.php';
    require_once 'includes/dbh.inc.php';
?>


<main class="main-wrapper">
    <div class="container">
        <div class="facility-list">
            <?php
                $check1 = fetchStatus($conn, "etf");
                if($check1["STATUS"] !== "AVAILABLE") { ?>
                    <div class="facility">
                        <div class="facility-img">
                            <img src="img/toilet.jpg" alt="ETF">
                        </div>
                        <div class="facility-name">
                            <span class="new-name">ETF</span><br>
                            <h3 style="text-align: center">Not Available</h3>
                        </div>
                    </div>
                <?php }
                else { ?>
                    <div class="facility">
                        <div class="facility-img">
                            <img src="img/toilet.jpg" alt="ETF">
                        </div>
                        <div class="facility-name">
                            <span class="new-name">ETF</span><br>
                            <h3 style="text-align: center">Available</h3>
                        </div>
                    </div>
                <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "seet");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/seet1.jpg" alt="SEET">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SEET</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/seet1.jpg" alt="SEET">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SEET</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "saat");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/saat1.jpg" alt="SAAT">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SAAT</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/saat1.jpg" alt="SAAT">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SAAT</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "set");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/set1.jpg" alt="SET">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SET</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/set1.jpg" alt="SET">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SET</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "crc");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="CRC">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">CRC</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="CRC">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">CRC</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "smat");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/smat1.jpg" alt="SMAT">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SMAT</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/smat1.jpg" alt="SMAT">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SMAT</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "sols");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="SOLS">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SOLS</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="SOLS">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SOLS</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "soc");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/soc1.jpg" alt="SOC">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SOC</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/soc1.jpg" alt="SOC">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SOC</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "sops");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/sops1.jpg" alt="SOPS">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SOPS</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/sops1.jpg" alt="SOPS">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SOPS</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "library");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/library1.jpg" alt="Library">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">LIBRARY</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/library1.jpg" alt="Library">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">Library</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "3in1old");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="3in1 Old">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">3-in-1 Old</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="3in1 Old">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">3-in-1 Old</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "3in1new");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="3in1 New">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">3-in-1 New</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="3in1 New">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">3-in-1 New</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "acad");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/ent1.jpg" alt="ACAD">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">Academic Building</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/ent1.jpg" alt="ACAD">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">Academic Building</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>
            <?php
            $check1 = fetchStatus($conn, "ent");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/ent1.jpg" alt="ENT">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">ENT Building</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/ent1.jpg" alt="ENT">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">ENT Building</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "sub");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/sub1.jpg" alt="SUB">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">S.U.B</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/sub1.jpg" alt="SUB">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">S.U.B</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "boc");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="BOC">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">Block of Classrooms</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="BOC">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">Block of Classrooms</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "1kcap");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="1K Cap">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">1000 capacity</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/toilet.jpg" alt="1K Cap">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">1000 Capacity</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>

            <?php
            $check1 = fetchStatus($conn, "sems");
            if($check1["STATUS"] !== "AVAILABLE") { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/sems1.jpg" alt="SEMS">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SEMS</span><br>
                        <h3 style="text-align: center">Not Available</h3>
                    </div>
                </div>
            <?php }
            else { ?>
                <div class="facility">
                    <div class="facility-img">
                        <img src="img/sems1.jpg" alt="SEMS">
                    </div>
                    <div class="facility-name">
                        <span class="new-name">SEMS</span><br>
                        <h3 style="text-align: center">Available</h3>
                    </div>
                </div>
            <?php }
            ?>
        </div>
    </div>

</main>
<?php
include_once 'footer.php'
?>