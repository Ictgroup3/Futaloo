<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/background.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/facilities.css">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/login.css">
    <link href='https://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet'>
    <title>Futaloo</title>
    <script src="https://kit.fontawesome.com/c1e544e65d.js" crossorigin="anonymous"></script>
</head>
<body>
<nav>
    <label class="logo"><a href="index.php">FUTA<span class="blue">LOO</span></a></label>
    <input type="checkbox" id="check">
    <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
    </label>
    <ul class="nav">
        <li><a href="index.php">HOME</a></li>
        <li><a href="facilities.php">FACILITIES</a></li>
        <li><a href="blog.php">BLOG</a></li>
        <?php
            if(isset($_SESSION["userUid"])) {
                echo "<li><a href=\"admin.php\">ADMIN</a></li>";
                echo "<li><a href=\"includes/logout.inc.php\">LOGOUT</a></li>";
            }
            else {
                echo "<li><a href=\"login.php\">LOG IN</a></li>";
            }
        ?>
    </ul>
</nav>
<div class="wrapper">
